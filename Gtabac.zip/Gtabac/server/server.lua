ESX = nil
local notif = "esx:showNotification"
local yes = true
local no = false
local notif2 = "esx:showAdvancedNotification"
local char = "CHAR_MP_ROBERTO"
local numbers = 8
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

TriggerEvent('esx_phone:registerNumber', 'redwood', 'Alerte Redwood', yes, yes) --- Si vous avez un GCPHONE
TriggerEvent('esx_society:registerSociety', 'redwood', 'redwood', 'society_redwood', 'society_redwood', 'society_redwood', {type = 'public'})

-- Recolte tabac blond
RegisterServerEvent("gtabac:rtbcblond")
AddEventHandler("gtabac:rtbcblond", function()
  local _src = source
  local xPlayer = ESX.GetPlayerFromId(_src)
  local item = "blond_seche"
  local tabac = xPlayer.getInventoryItem(item).count
  local truelle = xPlayer.getInventoryItem("truelle").count
  local count = 1

  if tabac > 50 then
    TriggerClientEvent(notif, _src, '~r~Vous n\'avez plus assez de place pour ceci')
  elseif truelle >= 1 then
  xPlayer.addInventoryItem(item, count)
  TriggerClientEvent(notif, _src, 'Vous avez récolter ~g~' .. count .. '~s~ ~o~Tabac Blond Séché ~s~' )
  else
    TriggerClientEvent(notif2, _src, '~r~IMPOSSIBLE', '~r~Erreur' , 'Vous n\'avez pas de ~r~truelle~s~ pour récolter !', 'CHAR_BLOCKED', 0)
  end
end)

-- Recolte tabac brun
RegisterServerEvent("gtabac:rtbcbrun")
AddEventHandler("gtabac:rtbcbrun", function()
  local _src = source
  local xPlayer = ESX.GetPlayerFromId(_src)
  local item = "brun_seche"
  local tabac = xPlayer.getInventoryItem(item).count
  local truelle = xPlayer.getInventoryItem("truelle").count
  local count = 1

  if tabac > 50 then
    TriggerClientEvent(notif, _src, '~r~Vous n\'avez plus assez de place pour ceci')
  elseif truelle >= 1 then
  xPlayer.addInventoryItem(item, count)
  TriggerClientEvent(notif, _src, 'Vous avez récolter ~g~' .. count .. '~s~ ~o~Tabac Brun Séché ~s~' )
  else
    TriggerClientEvent(notif2, _src, '~r~IMPOSSIBLE', '~r~Erreur' , 'Vous n\'avez pas de ~r~truelle~s~ pour récolter !', 'CHAR_BLOCKED', 0)
  end
end)

-- traitement tabac blond
RegisterServerEvent("gtabac:traitblond")
AddEventHandler("gtabac:traitblond", function()
  local _src = source
  local xPlayer = ESX.GetPlayerFromId(_src)
  local item = "tabac_blond"
  local item_need = "blond_seche"
  local tabac = xPlayer.getInventoryItem(item).count
  local need = xPlayer.getInventoryItem(item_need).count
  local count = 1

  if tabac > 35 then
    TriggerClientEvent(notif, _src, '~r~Vous n\'avez plus assez de place pour ceci')
  elseif need >= 3 then

    xPlayer.removeInventoryItem(item_need, 3)
    xPlayer.addInventoryItem(item, count)

  TriggerClientEvent(notif, _src, 'Vous avez traiter ~g~3~s~ ~y~Tabac Blond séché~s~' )
    else
        TriggerClientEvent(notif2, _src, '~r~IMPOSSIBLE', '~r~Erreur' , 'Vous n\'avez pas asser de tabac blond séché', 'CHAR_BLOCKED', 0)
  end
end)

-- Traitement tabac brun
RegisterServerEvent("gtabac:traitbrun")
AddEventHandler("gtabac:traitbrun", function()
  local _src = source
  local xPlayer = ESX.GetPlayerFromId(_src)
  local item = "tabac_brun"
  local item_need = "brun_seche"
  local tabac = xPlayer.getInventoryItem(item).count
  local need = xPlayer.getInventoryItem(item_need).count
  local count = 1

  if tabac > 35 then
    TriggerClientEvent(notif, _src, '~r~Vous n\'avez plus assez de place pour ceci')
  elseif need >= 3 then

    xPlayer.removeInventoryItem(item_need, 3)
    xPlayer.addInventoryItem(item, count)
    
  TriggerClientEvent(notif, _src, 'Vous avez traiter ~g~3~s~ ~o~Tabac Brun séché~s~' )
    else
        TriggerClientEvent(notif2, _src, '~r~IMPOSSIBLE', '~r~Erreur' , 'Vous n\'avez pas asser de tabac brun séché', 'CHAR_BLOCKED', 0)
  end
end)

-- Création Cigarette Blonde
RegisterServerEvent("gtabac:malboro")
AddEventHandler("gtabac:malboro", function()
  local _src = source
  local xPlayer = ESX.GetPlayerFromId(_src)
  local item = "marlboro"
  local item_need = "tabac_blond"
  local tabac = xPlayer.getInventoryItem(item).count
  local need = xPlayer.getInventoryItem(item_need).count
  local count = 1

  if tabac > 12 then
    TriggerClientEvent(notif, _src, '~r~Vous n\'avez plus assez de place pour ceci')
  elseif need >= 5 then

    xPlayer.removeInventoryItem(item_need, 5)
    xPlayer.addInventoryItem(item, count)
    
  TriggerClientEvent(notif, _src, 'Vous avez fabriquer ~g~' .. count .. '~s~ ~o~Marlboro~s~' )
    else
        TriggerClientEvent(notif2, _src, '~r~IMPOSSIBLE', '~r~Erreur' , 'Vous n\'avez pas asser de tabac blond', 'CHAR_BLOCKED', 0)
  end
end)

-- Création Cigarette Brune
RegisterServerEvent("gtabac:gitanes")
AddEventHandler("gtabac:gitanes", function()
  local _src = source
  local xPlayer = ESX.GetPlayerFromId(_src)
  local item = "gitanes"
  local item_need = "tabac_brun"
  local tabac = xPlayer.getInventoryItem(item).count
  local need = xPlayer.getInventoryItem(item_need).count
  local count = 1

  if tabac > 12 then
    TriggerClientEvent(notif, _src, '~r~Vous n\'avez plus assez de place pour ceci')
  elseif need >= 5 then

    xPlayer.removeInventoryItem(item_need, 5)
    xPlayer.addInventoryItem(item, count)
    
  TriggerClientEvent(notif, _src, 'Vous avez fabriquer ~g~' .. count .. '~s~ ~o~Gitane~s~' )
    else
        TriggerClientEvent(notif2, _src, '~r~IMPOSSIBLE', '~r~Erreur' , 'Vous n\'avez pas asser de tabac brun', 'CHAR_BLOCKED', 0)
  end
end)

-- Vente Marloboro
RegisterNetEvent('gtabac:ventem')
AddEventHandler('gtabac:ventem', function(amount)

    local _src = source
    local item_need = "marlboro"
    local xPlayer = ESX.GetPlayerFromId(_src)
    local societyAccount = nil
    local count_item = xPlayer.getInventoryItem(item_need).count

    if count_item >= amount then
            local money = Config.Vente.SocieteM*amount
            xPlayer.removeInventoryItem(item_need, amount)
            local societyAccount = nil

            TriggerEvent('esx_addonaccount:getSharedAccount', 'society_redwood', function(account)
                societyAccount = account
            end)
            if societyAccount ~= nil then
                societyAccount.addMoney(money)
                TriggerClientEvent(notif2, _src, 'MAZE BANK', '~g~Entreprise Crédité' , 'L\'entreprise a était crédité de ~r~'..money..'~s~$ pour la vente', 'CHAR_BANK_MAZE', 8)
          end
        end
        end)

-- Vente Marloboro
RegisterNetEvent('gtabac:venteg')
AddEventHandler('gtabac:venteg', function(amount)

    local _src = source
    local item_need = "gitanes"
    local xPlayer = ESX.GetPlayerFromId(_src)
    local societyAccount = nil
    local count_item = xPlayer.getInventoryItem(item_need).count

    if count_item >= amount then
            local money = Config.Vente.SocieteG*amount
            xPlayer.removeInventoryItem(item_need, amount)
            local societyAccount = nil

            TriggerEvent('esx_addonaccount:getSharedAccount', 'society_redwood', function(account)
                societyAccount = account
            end)
            if societyAccount ~= nil then
                societyAccount.addMoney(money)
                TriggerClientEvent(notif2, _src, 'MAZE BANK', '~g~Entreprise Crédité' , 'L\'entreprise a était crédité de ~r~'..money..'~s~$ pour la vente', 'CHAR_BANK_MAZE', 8)
          end
        end
        end)

RegisterServerEvent('gtabac:setmoney_society')
AddEventHandler('gtabac:setmoney_society', function()
    local _src = source
    MySQL.Async.fetchAll("SELECT * FROM addon_account_data WHERE account_name = 'society_tabac'", {}, function(data)
      local sous = data[1].money
        TriggerClientEvent(notif, _src, "Le compte de l'entreprise possède = ~r~"..sous.." $")
    end)
end)

RegisterServerEvent('OuvertRed')
    AddEventHandler('OuvertRed', function()
        local _source = source
        local xPlayer = ESX.GetPlayerFromId(_source)
        local xPlayers	= ESX.GetPlayers()
        for i=1, #xPlayers, 1 do
            local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
            TriggerClientEvent(notif2, xPlayers[i], '~r~Redwood', '~b~Annonce', 'Redwood est ~g~ouvert~s~', char, numbers)
        end
    end)
    
    RegisterServerEvent('FermerRed')
    AddEventHandler('FermerRed', function()
        local _source = source
        local xPlayer = ESX.GetPlayerFromId(_source)
        local xPlayers	= ESX.GetPlayers()
        for i=1, #xPlayers, 1 do
            local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
            TriggerClientEvent(notif2, xPlayers[i], '~r~Redwood', '~b~Annonce', 'Redwood est ~r~fermer~s~', 'CHAR_BLOCKED', numbers)
        end
    end)
    
    RegisterServerEvent('RecruRed')
    AddEventHandler('RecruRed', function (target)
    
        local _source = source
        local xPlayer = ESX.GetPlayerFromId(_source)
        local xPlayers = ESX.GetPlayers()
        for i=1, #xPlayers, 1 do
        local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
        TriggerClientEvent(notif2, xPlayers[i], '~r~Redwood', '~b~Annonce', '~b~Recrutement~s~ en cours à Redwood !', char, numbers)
    
        end
    end)